<?php

require "ezc/Base/src/exceptions/exception.php";
require "ezc/Mail/src/interfaces/part.php";
require "ezc/Mail/src/mail.php";
require "ezc/Mail/src/composer.php";
require "ezc/Base/src/struct.php";
require "ezc/Mail/src/parser/headers_holder.php";
require "ezc/Mail/src/structs/mail_address.php";
require "ezc/Mail/src/parts/text.php";
require "ezc/Mail/src/parts/multipart.php";
require "ezc/Mail/src/parts/multiparts/multipart_alternative.php";
require "ezc/Mail/src/interfaces/transport.php";
require "ezc/Mail/src/exceptions/mail_exception.php";
require "ezc/Mail/src/exceptions/transport_exception.php";
require "ezc/Mail/src/exceptions/transport_smtp_exception.php";
require "ezc/Mail/src/transports/transport_smtp.php";
require "ezc/Mail/src/tools.php";
require "ezc/Mail/src/internal/header_folder.php";

require "mail.php";

Mail::send('example.xml', 'transformer.xsl', 'Example Sample', 'example@example.org');

?>