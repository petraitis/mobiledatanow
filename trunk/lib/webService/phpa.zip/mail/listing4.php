<?php
/* static method MailFormatter::render() */

	/**
	 * Render a message body
	 *
	 * @param SimpleXMLElement $template A pointer to the body template
	 * @param int $width The maximum allowable width
	 * @return string The formatted message
	 */
	static function render(SimpleXMLElement $template, $width = MailFormatter::MAXIMUM_LINE_WIDTH) {
		$result = '';

		foreach ($template as $element) {
			switch ($element->getName()) {
				case 'h1':
					$result .= MailFormatter::heading((string) $element, $width);
					break;

				case 'p':
					$result .= wordwrap(trim((string) $element), $width) . "\n\n";
					break;

				case 'callout':
					$result .= MailFormatter::callout((string) $element, $width);
					break;

				case 'table':
					$table = new Table($element, $width);
					$result .= $table->render();
					break;

				default:
					throw new Exception("Invalid element " . $element->getName() . " found");
			}
		}

		return $result;
	}

?>