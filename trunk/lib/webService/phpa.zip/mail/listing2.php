<?php

class TableCell {
	/**
	 * The cell's minimum width
	 *
	 * @var int
	 */
	public $minW;

	/**
	 * The cell's maximum width
	 *
	 * @var int
	 */
	public $maxW;

	/**
	 * The column alignment, expressed as one of the 
	 * STR_PAD_* constants
	 *
	 * @var int
	 */
	public $alignment;

	/**
	 * The column span of the cell
	 *
	 * @var int
	 */
	public $colSpan;

	/**
	 * An array that contains the individual lines of text
	 * that make up the contents of the cell
	 *
	 * @var array
	 */
	protected $lines;

	/**
	 * Builds the object, performing all appropriate size calculations
	 *
	 * @param SimpleXMLElement $cell The input element that contains the cell
	 *                               to be imported
	 */
	function __construct(SimpleXMLElement $cell) {

		// Remove all but <br> and <p> tags from the source
		$string = strip_tags($cell->asXml(), "<br><br/><p><p/>");

		// Remove newlines, tabs and multiple spaces, which
		// are not semantic in XML
		$string = str_replace(
			array("\n", "\t", '  '),
			array('', '', ' '),
			$string);

		// Replace breaks with single newlines, and paragraphs with two
		// newlines. (Browsers render more than W3C standards permit.)
		$string = preg_replace(
			array('#</P\s*>#i', '#<BR\s*/?>#i', '#<P\s*/?>#i'),
			array("", "\n", "\n\n"),
			$string);

		// Finally, break lines apart along newline characters
		$this->lines = explode("\n", $string);

		// Cycle through each line, removing extra space
		// and computing the maximum and minimum width
		foreach ($this->lines as &$line) {
			$line = trim($line);

			// Calculate the maximum width of this line
			$this->maxW = max($this->maxW, strlen($line));

			if ($cell->getName() == 'th') {
				// If this is a <th> element, we do not want to wrap
				$this->minW = strlen($line);
			} else {
				// Find the minimum width as the length of the longest
				// word on the line
				$words = explode(' ', $line);
				foreach ($words as $word) {
					$this->minW = max($this->minW, strlen($word));
				}
			}
		}

		// Read the column span, if any
		$this->colSpan = isset($cell['colspan']) ? (string) $cell['colspan'] : 1;

		// Read the alignment
		if (isset($cell['align'])) {
			switch (strtolower(trim($cell['align']))) {
				case 'center':
					$this->alignment = STR_PAD_BOTH;
					break;

				case 'right':
					$this->alignment = STR_PAD_LEFT;
					break;

				case 'left':
				default:
					$this->alignment = STR_PAD_RIGHT;
			}
		} else {
			// By default, we center <th> elements, and left-align columns
			// that do not have a specific alignment attribute.
			if ($cell->getName() == 'th') {
				$this->alignment = STR_PAD_BOTH;
			} else {
				$this->alignment = STR_PAD_RIGHT;
			}
		}
	}

	/**
	 * Returns the cell formatted to a specific length as an array of lines
	 *
	 * @param int $width The width of the cell
	 */
	function getFormatted($width) {
		$result = array();

		// Go through each line, wordwrapping it as appropriate
		// and padding the resulting text according to our alignment
		// attribute
		foreach ($this->lines as $line) {
			if (strlen($line) > $width) {
				$line = explode("\n", wordwrap($line, $width, "\n", true));

				foreach ($line as $lineEntry) {
					$result[] = str_pad($lineEntry, $width, ' ', $this->alignment);
				}
			} else {
				$result[] = str_pad($line, $width, ' ', $this->alignment);
			}
		}

		// Return the array--the table renderer will still need it to
		// render multiple columns
		return $result;
	}
}

class TableColumn {
	public $minW;
	public $maxW;

	public $width;

	public $fixed = false;
	public $unfixable = false;

	function updateMinW($newMinW) {
		$this->minW = max($this->minW, $newMinW);
	}

	function updateMaxW($newMaxW) {
		$this->maxW = max($this->maxW, $newMaxW);
		$this->width = $this->maxW;
	}
}

?>