<?php

class MailFormatter {
	const MAXIMUM_LINE_WIDTH = 70;

	/**
	 * Find the maximum length required to display
	 * an array of lines.
	 *
	 * @param string $line A line of text
	 * @param mixed $key The key of the array item
	 * @param int $maxLen Container for the maximum
	 *                    length of the array
	 */
	static function findMaxLength($line, $key, &$maxLen) {
		$maxLen = max($maxLen, strlen($line));
	}

	/**
	 * Format a section heading
	 *
	 * @param string $text The text to format
	 * @param int $width The maximum width
	 * @return string The formatted heading
	 */
	static function heading($text, $width = MailFormatter::MAXIMUM_LINE_WIDTH) {
		$text = wordwrap($text, $width, "\n", true);
		$splitText = explode("\n", strtoupper(wordwrap($text, $width, "\n", true)));
		$maxWidth = 0;

		array_walk($splitText, array('MailFormatter', 'findMaxLength'), &$maxWidth);

		return $text . "\n" . str_repeat('=', $maxWidth) . "\n";
	}

	/**
	 * Format a callout
	 *
	 * @param string $text The text to format
	 * @param int $width The maximum width allowed
	 * @return string The formatted text
	 */
	static function callout($text, $width = MailFormatter::MAXIMUM_LINE_WIDTH) {
		$width -=4 ;
		$text = explode("\n", wordwrap($text, $width, "\n", true));
		$result = '';

		foreach ($text as $line) {
			$result .= '| ' . str_pad($line, $width, ' ', STR_PAD_RIGHT) . " |\n";
		}

		$border = '+' . str_repeat('-', $width + 2) . "+\n";

		return $border . $result . $border . "\n";
	}

}

?>