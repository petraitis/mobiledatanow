<?php

class Table {
	/**
	 * Container for all the rows in the table
	 *
	 * @var array
	 */
	protected $rows = array();

	/**
	 * Conainer for all the column definitions
	 *
	 * @var array
	 */
	protected $columns = array();

	/**
	 * The maximum allowable width of the table
	 *
	 * @var int
	 */
	protected $width;

	/**
	 * Constructor
	 *
	 * @param SimpleXMLElement $table The table element
	 * @param int $width The maximum allowable width
	 */
	function __construct(SimpleXMLElement $table, $width = 70) {
		$rowIndex = 0;
		$maxColumns = 0;
		$multiSpanCells = array();

		// Go through all the rows

		foreach ($table as $tr) {
			$row = array();
			$columnIndex = 0;
			$cellIndex = 0;

			// Go through all the cells

			foreach ($tr as $td) {
				$cell = new TableCell($td);

				// Determine how many columns we need

				for ($i = 0; $i < $cell->colSpan; $i++) {
					if (!isset($this->columns[$columnIndex])) {
						$this->columns[$columnIndex + $i] = new TableColumn();
					}
				}

				// Determine the MinW and MaxW of the column
				// unless the cell spans multiple columns

				if ($cell->colSpan > 1) {
					$multiSpanCells[] = array($rowIndex, $cellIndex, $columnIndex);
				} else {
					$this->columns[$columnIndex]->updateMinW($cell->minW);
					$this->columns[$columnIndex]->updateMaxW($cell->maxW);
				}

				$row[$columnIndex] = $cell;
				$columnIndex += $cell->colSpan;
				$cellIndex++;
			}

			$this->rows[$rowIndex] = $row;
			$maxColumns = max(count($row), $maxColumns);
			$rowIndex++;
		}

		// Handle the multi-column cells

		foreach ($multiSpanCells as $multiSpanCell) {
			$cell = $table->tr[$multiSpanCell[0]]->td[$multiSpanCell[1]];

			$w = 0;
			$mw = 0;

			// Determine the width available to the cell

			for ($i = 0; $i < $cell->colSpan; $i++) {
				$w += $this->columns[$multiSpanCell[2] + $i]->maxW;
				$mw += $this->columns[$multiSpanCell[2] + $i]->minW;
			}

			// Calculate whether the width is enough and/or distribute
			// the difference across the columns

			$wDiff = max(0, $cell->maxW - $w);
			$mwDiff = max(0, $cell->minW - $w);

			for ($i = 0; $i < $cell->colSpan; $i++) {
				$this->columns[$multiSpanCell[2] + $i]->maxW += floor($wDiff * $this->columns[$multiSpanCell[2] + $i]->maxW / $w);
				$this->columns[$multiSpanCell[2] + $i]->minW += floor($mwDiff * $this->columns[$multiSpanCell[2] + $i]->minW / $mw);
			}
		}

		$this->width = $width - 4 * $maxColumns;
		$this->calcColumnWidths();
	}

	/**
	 * Calculate the appropriate width of every row
	 *
	 */
	protected function calcColumnWidths() {
		do {
			$tableWidth = 0;

			// Determine the current width of the table
			foreach ($this->columns as $column) {
				$tableWidth += $column->width;
			}

			// If the table is too wide, we need
			// to reduce its size

			if ($tableWidth > $this->width) {
				$w = $this->width - $tableWidth;

				$logSum = 0;
				$maxFixedWidth = 0;
				$widestFixed = 0;

				// Go through each column, and determine whether
				// we can reduce its size because it is not
				// fixed or is unfixable

				foreach ($this->columns as $key => $column) {
					if (!$column->fixed || $column->unfixable) {
						$logSum += log($column->width);
					} else if (!$column->unfixable && $column->width > $maxFixedWidth) {
						$widestFixed = $key;
						$maxFixedWidth = $column->width;
					}
				}

				// Distribute the available reduction among
				// all the eligible columns

				foreach ($this->columns as $column) {
					if (!$column->fixed || $column->unfixable) {
						$column->width += ceil($w * log($column->width) / $logSum);

						if (!$column->unfixable && $column->width < $column->minW) {
							$column->width = $column->minW;
							$column->fixed = true;
						}
					}
				}

				// If no unfixed or unfixable columns were found
				// on this pass, we make the widest fixed
				// column unfixable so that the algorithm
				// will pick it up on the next pass if needed

				if ($logSum == 0) {
					$this->columns[$widestFixed]->unfixable = true;
				}
			}
		} while ($tableWidth > $this->width);
	}

	/**
	 * Renders the table
	 *
	 * @return string The rendered table
	 */
	function render() {

		// Generate the table's top and bottom border

		$border = '+';
		foreach ($this->columns as $column) {
			$border .= str_repeat('-', $column->width + 2) . '+';
		}
		$border .= "\n";

		$result = $border;

		// Go through each row

		foreach ($this->rows as $row) {
			$columnData = array();
			$maximumLines = 1;

			// Go through each cell on this row

			foreach ($row as $cellNumber => $cell) {
				$cellWidth = 0;

				// Determine the actual width of the cell

				if ($cell->colSpan > 1) {
					for ($i = 0; $i < $cell->colSpan; $i++) {
						$cellWidth += $this->columns[$cellNumber + $i]->width + 2;
					}
				} else {
					$cellWidth = $this->columns[$cellNumber]->width;
				}

				// Prepare the cell data for presentation

				$lines = $cell->getFormatted($cellWidth);
				$maximumLines = max($maximumLines, count($lines));
				$columnData[] = array($cellWidth, $cell->colSpan, $lines);
			}

			// Render the row

			for ($i = 0; $i < $maximumLines; $i++) {
				$line = array();
				foreach ($columnData as $k => $v) {
					if (isset($v[2][$i])) {
						$line[] = $v[2][$i];
					} else {
						// This cell is empty--render whitespace
						$line[] = str_repeat(' ', $v[0] + $v[1] - 1);
					}
				}

				$result .= '| ' . implode(' | ', $line) . " |\n";
			}

			// Append a bottom border

			$result .= $border;
		}

		return $result;
	}
}

?>