<?php

class Mail {
	function send($template, $transformer, $toName, $toAddress) {
		$xml = new DOMDocument();
		$xml->load($template);
		$xsl = new DOMDocument();
		$xsl->load($transformer);
		
		$transformer = new XSLTProcessor();
		$transformer->importStylesheet($xsl);
		
		$html = $transformer->transformToDoc($xml)->saveHTML();
		
		$xml = simplexml_import_dom($xml);
		$text = MailFormatter::render($xml->body[0]);
		
		$mail = new ezcMailComposer();
		$mail->from = new ezcMailAddress($xml['address'], $xml['from']);
		$mail->addTo(new ezcMailAddress($toAddress, $toName));
		$mail->subject = (string)$xml->subject;
		$mail->plainText = $text;
		$mail->htmlText = $html;
		$mail->build();
		
		$transport = new ezcMailSmtpTransport('localhost');
		$transport->send($mail);
	}
}

?>