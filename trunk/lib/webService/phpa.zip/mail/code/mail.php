<?php

class TableCell {
	/**
	 * The cell's minimum width
	 *
	 * @var int
	 */
	public $minW;

	/**
	 * The cell's maximum width
	 *
	 * @var int
	 */
	public $maxW;

	/**
	 * The columns alignment, expressed as one of the 
	 * STR_PAD_* constants
	 *
	 * @var int
	 */
	public $alignment;

	/**
	 * The column span of the cell
	 *
	 * @var int
	 */
	public $colSpan;

	/**
	 * An array that contains the individual lines of text
	 * that make up the contents of the cell
	 *
	 * @var array
	 */
	protected $lines;

	/**
	 * Builds the object, performing all appropriate size calculations
	 *
	 * @param SimpleXMLElement $cell The input element that contains the cell
	 *                               to be imported
	 */
	function __construct(SimpleXMLElement $cell) {

		// Remove all but <br> and <p> tags from the source
		$string = strip_tags($cell->asXml(), "<br><br/><p><p/>");

		// Remove newlines, tabs and multiple spaces, which
		// are not semantic in XML
		$string = str_replace(
			array("\n", "\t", '  '),
			array('', '', ' '), 
			$string);

		// Replace breaks with single newlines, and paragraphs with two
		// newlines. (Browsers render more than W3C standards permit.)
		$string = preg_replace(
			array('#</P\s*>#i', '#<BR\s*/?>#i', '#<P\s*/?>#i'),
			array("", "\n", "\n\n"),
			$string);

		// Finally, break lines apart along newline characters
		$this->lines = explode("\n", $string);

		// Cycle through each line, removing extra space
		// and computing the maximum and minimum width
		foreach ($this->lines as &$line) {
			$line = trim($line);

			// Calculate the maximum width of this line
			$this->maxW = max($this->maxW, strlen($line));

			if ($cell->getName() == 'th') {
				// If this is a <th> element, we do not want to wrap
				$this->minW = strlen($line);
			} else {
				// Find the minimum width as the length of the longest
				// word on the line
				$words = explode(' ', $line);
				foreach ($words as $word) {
					$this->minW = max($this->minW, strlen($word));
				}
			}
		}

		// Read the column span, if any
		$this->colSpan = isset($cell['colspan']) ? (string) $cell['colspan'] : 1;

		// Read the alignment
		if (isset($cell['align'])) {
			switch (strtolower(trim($cell['align']))) {
				case 'center':
					$this->alignment = STR_PAD_BOTH;
					break;

				case 'right':
					$this->alignment = STR_PAD_LEFT;
					break;

				case 'left':
				default:
					$this->alignment = STR_PAD_RIGHT;
			}
		} else {
			// By default, we center <th> elements, and left-align columns
			// that do not have a specific alignment attribute.
			if ($cell->getName() == 'th') {
				$this->alignment = STR_PAD_BOTH;
			} else {
				$this->alignment = STR_PAD_RIGHT;
			}
		}
	}

	/**
	 * Returns the cell formatted to a specific length as an array of lines
	 *
	 * @param int $width The width of the cell
	 */
	function getFormatted($width) {
		$result = array();

		// Go through each line, wordwrapping it as appropriate
		// and padding the resulting text according to our alignment
		// attribute
		foreach ($this->lines as $line) {
			if (strlen($line) > $width) {
				$line = explode("\n", wordwrap($line, $width, "\n", true));

				foreach ($line as $lineEntry) {
					$result[] = str_pad($lineEntry, $width, ' ', $this->alignment);
				}
			} else {
				$result[] = str_pad($line, $width, ' ', $this->alignment);
			}
		}

		// Return the array--the table renderer will still need it to
		// render multiple columns
		return $result;
	}
}

class TableColumn {
	public $minW;
	public $maxW;

	public $width;

	public $fixed = false;
	public $unfixable = false;

	function updateMinW($newMinW) {
		$this->minW = max($this->minW, $newMinW);
	}

	function updateMaxW($newMaxW) {
		$this->maxW = max($this->maxW, $newMaxW);
		$this->width = $this->maxW;
	}
}

class Table {
	/**
	 * Container for all the rows in the table
	 *
	 * @var array
	 */
	protected $rows = array();

	/**
	 * Conainer for all the column definitions
	 *
	 * @var array
	 */
	protected $columns = array();

	/**
	 * The maximum allowable width of the table
	 *
	 * @var int
	 */
	protected $width;

	/**
	 * Constructor
	 *
	 * @param SimpleXMLElement $table The table element
	 * @param int $width The maximum allowable width
	 */
	function __construct(SimpleXMLElement $table, $width = 70) {
		$rowIndex = 0;
		$maxColumns = 0;
		$multiSpanCells = array();

		// Go through all the rows

		foreach ($table as $tr) {
			$row = array();
			$columnIndex = 0;
			$cellIndex = 0;

			// Go through all the cells

			foreach ($tr as $td) {
				$cell = new TableCell($td);

				// Determine how many columns we need

				for ($i = 0; $i < $cell->colSpan; $i++) {
					if (!isset($this->columns[$columnIndex])) {
						$this->columns[$columnIndex + $i] = new TableColumn();
					}
				}

				// Determine the MinW and MaxW of the column
				// unless the cell spans multiple columns

				if ($cell->colSpan > 1) {
					$multiSpanCells[] = array($rowIndex, $cellIndex, $columnIndex);
				} else {
					$this->columns[$columnIndex]->updateMinW ($cell->minW);
					$this->columns[$columnIndex]->updateMaxW ($cell->maxW);
				}

				$row[$columnIndex] = $cell;
				$columnIndex += $cell->colSpan;
				$cellIndex++;
			}

			$this->rows[$rowIndex] = $row;
			$maxColumns = max(count($row), $maxColumns);
			$rowIndex++;
		}

		// Handle the multi-column cells

		foreach ($multiSpanCells as $multiSpanCell) {
			$cell = $table->tr[$multiSpanCell[0]]->td[$multiSpanCell[1]];

			$w = 0;
			$mw = 0;

			// Determine the width available to the cell

			for ($i = 0; $i < $cell->colSpan; $i++) {
				$w += $this->columns[$multiSpanCell[2] + $i]->maxW;
				$mw += $this->columns[$multiSpanCell[2] + $i]->minW;
			}

			// Calculate whether the width is enough and/or distribute
			// the difference across the columns

			$wDiff = max(0, $cell->maxW - $w);
			$mwDiff = max(0, $cell->minW - $w);

			for ($i = 0; $i < $cell->colSpan; $i++) {
				$this->columns[$multiSpanCell[2] + $i]->maxW += floor($wDiff * $this->columns[$multiSpanCell[2] + $i]->maxW / $w);
				$this->columns[$multiSpanCell[2] + $i]->minW += floor($mwDiff * $this->columns[$multiSpanCell[2] + $i]->minW / $mw);
			}
		}

		$this->width = $width - 4 * $maxColumns;
		$this->calcColumnWidths();
	}

	/**
	 * Calculate the appropriate width of every row
	 *
	 */
	protected function calcColumnWidths() {
		do {
			$tableWidth = 0;

			// Determine the current width of the table
			foreach ($this->columns as $column) {
				$tableWidth += $column->width;
			}

			// If the table is too wide, we need
			// to reduce its size

			if ($tableWidth > $this->width) {
				$w = $this->width - $tableWidth;

				$logSum = 0;
				$maxFixedWidth = 0;
				$widestFixed = 0;

				// Go through each column, and determine whether
				// we can reduce its size because it is not
				// fixed or is unfixable

				foreach ($this->columns as $key => $column) {
					if (!$column->fixed || $column->unfixable) {
						$logSum += log($column->width);
					} else if (!$column->unfixable && $column->width > $maxFixedWidth) {
						$widestFixed = $key;
						$maxFixedWidth = $column->width;
					}
				}

				// Distribute the available reduction among
				// all the eligible columns

				foreach ($this->columns as $column) {
					if (!$column->fixed || $column->unfixable) {
						$column->width += ceil($w * log($column->width) / $logSum);

						if (!$column->unfixable && $column->width < $column->minW) {
							$column->width = $column->minW;
							$column->fixed = true;
						}
					}
				}

				// If no unfixed or unfixable columns were found
				// on this pass, we make the widest fixed
				// column unfixable so that the algorithm
				// will pick it up on the next pass if needed

				if ($logSum == 0) {
					$this->columns[$widestFixed]->unfixable = true;
				}
			}
		} while($tableWidth > $this->width);
	}

	/**
	 * Renders the table
	 *
	 * @return string The rendered table
	 */
	function render() {

		// Generate the table's top and bottom border

		$border = '+';
		foreach ($this->columns as $column) {
			$border .= str_repeat('-', $column->width + 2) . '+';
		}
		$border .= "\n";

		$result = $border;

		// Go through each row

		foreach ($this->rows as $row) {
			$columnData = array();
			$maximumLines = 1;

			// Go through each cell on this row

			foreach ($row as $cellNumber => $cell) {
				$cellWidth = 0;

				// Determine the actual width of the cell

				if ($cell->colSpan > 1) {
					for ($i = 0; $i < $cell->colSpan; $i++) {
						$cellWidth += $this->columns[$cellNumber + $i]->width + 2;
					}
				} else {
					$cellWidth = $this->columns[$cellNumber]->width;
				}

				// Prepare the cell data for presentation

				$lines = $cell->getFormatted($cellWidth);
				$maximumLines = max($maximumLines, count($lines));
				$columnData[] = array($cellWidth, $cell->colSpan, $lines);
			}

			// Render the row

			for ($i = 0; $i < $maximumLines; $i++) {
				$line = array();
				foreach ($columnData as $k => $v) {
					if (isset($v[2][$i])) {
						$line[] = $v[2][$i];
					} else {
						// This cell is empty--render whitespace
						$line[] = str_repeat(' ', $v[0] + $v[1] - 1);
					}
				}

				$result .= '| ' . implode(' | ', $line) . " |\n";
			}

			// Append a bottom border

			$result .= $border;
		}

		return $result;
	}
}

class MailFormatter {
	const MAXIMUM_LINE_WIDTH = 70;

	/**
	 * Find the maximum length required to display
	 * an array of lines.
	 *
	 * @param string $line A line of text
	 * @param mixed $key The key of the array item
	 * @param int $maxLen Container for the maximum
	 *                    length of the array
	 */
	static function findMaxLength($line, $key, &$maxLen) {
		$maxLen = max($maxLen, strlen($line));
	}

	/**
	 * Format a section heading
	 *
	 * @param string $text The text to format
	 * @param int $width The maximum width
	 * @return string The formatted heading
	 */
	static function heading($text, $width = MailFormatter::MAXIMUM_LINE_WIDTH) {
		$text = wordwrap(trim($text), $width, "\n", true);
		$splitText = explode("\n", strtoupper(wordwrap($text, $width, "\n", true)));
		$maxWidth = 0;

		array_walk($splitText, array('MailFormatter', 'findMaxLength'), &$maxWidth);

		return $text . "\n" . str_repeat('=', $maxWidth) . "\n";
	}

	/**
	 * Format a callout
	 *
	 * @param string $text The text to format
	 * @param int $width The maximum width allowed
	 * @return string The formatted text
	 */
	static function callout($text, $width = MailFormatter::MAXIMUM_LINE_WIDTH) {
		$width -=4 ;
		$text = explode("\n", wordwrap(trim($text), $width, "\n", true));
		$result = '';

		foreach ($text as $line) {
			$result .= '| ' . str_pad($line, $width, ' ', STR_PAD_RIGHT) . " |\n";
		}

		$border = '+' . str_repeat('-', $width + 2) . "+\n";

		return $border . $result . $border . "\n";
	}

	/**
	 * Render a message body
	 *
	 * @param SimpleXMLElement $template A pointer to the body template
	 * @param int $width The maximum allowable width
	 * @return string The formatted message
	 */
	static function render(SimpleXMLElement $template, $width = MailFormatter::MAXIMUM_LINE_WIDTH) {
		$result = '';

		foreach ($template as $element) {
			switch ($element->getName()) {
				case 'h1':
					$result .= MailFormatter::heading((string)$element, $width);
					break;

				case 'p':
					$result .= wordwrap(trim((string)$element), $width) . "\n\n";
					break;

				case 'callout':
					$result .= MailFormatter::callout((string)$element, $width);
					break;

				case 'table':
					$table = new Table($element, $width);
					$result .= $table->render();
					break;

				default:
					throw new Exception("Invalid element " . $element->getName() . " found");
			}
		}

		return $result;
	}
}

class Mail {

	/**
	 * Send a formatted e-mail
	 *
	 * @param string $template The source template filename
	 * @param string $transformer The XSL transformer filename
	 * @param string $toName The name of the recipient
	 * @param string $toAddress The e-mail address of the recipient
	 */
	function send($template, $transformer, $toName, $toAddress) {
		$xml = new DOMDocument();
		$xml->load($template);
		$xsl = new DOMDocument();
		$xsl->load($transformer);

		$transformer = new XSLTProcessor();
		$transformer->importStylesheet($xsl);

		$html = $transformer->transformToDoc($xml)->saveHTML();

		$xml = simplexml_import_dom($xml);
		$text = MailFormatter::render($xml->body[0]);

		$mail = new ezcMailComposer();
		$mail->from = new ezcMailAddress($xml['address'], $xml['from']);
		$mail->addTo(new ezcMailAddress($toAddress, $toName));
		$mail->subject = (string) $xml->subject;
		$mail->plainText = $text;
		$mail->htmlText = $html;
		$mail->build();

		$transport = new ezcMailSmtpTransport('localhost');
		$transport->send($mail);
	}
}