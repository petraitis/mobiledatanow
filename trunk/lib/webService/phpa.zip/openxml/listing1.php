<?php

// Create new PHPExcel object
$PHPExcel = new PHPExcel();

// Set properties
$PHPExcel->getProperties()->setCreator("Maarten Balliauw");
$PHPExcel->getProperties()->setLastModifiedBy("Maarten Balliauw");
$PHPExcel->getProperties()->setTitle("Country codes");
$PHPExcel->getProperties()->setSubject("Country codes with their flag");
$PHPExcel->getProperties()->setDescription("Country codes with their flag");

// Set page header and footer (for printing)
$PHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader('&L&BCountry codes&RPrinted on &D');
$PHPExcel->getActiveSheet()->getHeaderFooter()->setOddFooter('&L&B' . $PHPExcel->getProperties()->getTitle() . '&RPage &P of &N');

// Set page size (for printing)
$PHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);

?>
