<?php

// Set table header styles
$PHPExcel->getActiveSheet()->getStyle('A3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_GRADIENT_LINEAR);
$PHPExcel->getActiveSheet()->getStyle('A3')->getFill()->getStartColor()->setARGB('FFA0A0A0');
$PHPExcel->getActiveSheet()->getStyle('A3')->getFill()->getEndColor()->setARGB('FFFFFFFF');
$PHPExcel->getActiveSheet()->getStyle('A3')->getFill()->setRotation(90);
$PHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);
$PHPExcel->getActiveSheet()->duplicateStyle( $PHPExcel->getActiveSheet()->getStyle('A3'), 'A3:C3' );

// Set table header borders
$PHPExcel->getActiveSheet()->getStyle('A3')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$PHPExcel->getActiveSheet()->getStyle('A3')->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$PHPExcel->getActiveSheet()->getStyle('B3')->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$PHPExcel->getActiveSheet()->getStyle('C3')->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$PHPExcel->getActiveSheet()->getStyle('C3')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

?>
